<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>VIRTUOSO OLA WORLD</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="form.css" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="customIfemi.css" rel="stylesheet" />
        <script src="form.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="main.js"></script>
    </head>
    <body >

            <!--CODES FOR HEADER AND NAVIGATION BAR -->
    
    <div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

        <div class="well well-sm" style="background: blue; color: white; border: none;">
            <div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
                <h6><span class="glyphicon glyphicon-envelope">virtuosworld@gmail.com  <span class="glyphicon glyphicon-earphone">0814-037-4189, 0811-108-6922</span></span></h6>
            </div>
        </div>

        <div class="container col-sm-12" style="margin-top: -20px;">    
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
                    <span class="sr-only">navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <a href="#" class="navbar-brand"><img class="img-responsive" src="images/vowlogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>VIRTUOSO OLA WORLD</strong></h5></a>

            </div>
        <div class="collapse navbar-collapse" id="collapse">
            <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li class="active"><a href="formpage.php">Contact Us</a></li>               
            </ul>

        </div>
    </div>
</div>

<p></p>br></p>
<p></p>br></p>

<!-- contact form section -->

        <div class="container">
            <div class="row">

             <div class="panel panel-primary"> <!--Panel-default, panel-info, -->
              <div class="panel-body">

                <div class="col-md-6" id="form_container">
                    <h3 style="color: red;">Contact Form</h3> 
                    <p> Please send your message below. We will get back to you at the earliest! </p>
                    <form role="form" method="post" id="reused_form">
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <label for="message"> Message:</label>
                                <textarea class="form-control" type="textarea" id="message" name="message" maxlength="6000" rows="7"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label for="name"> Your Name:</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-sm-6 form-group">
                                <label for="email"> Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <button type="submit" class="btn btn-lg btn-primary pull-right" >Send &rarr;</button>
                            </div>
                        </div>
                    </form>
                    <div id="success_message" style="width:100%; height:100%; display:none; "> <h3>Posted your message successfully!</h3> </div>
                    <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry there was an error sending your form. </div>
                </div>                           

<br />
<!-- Company contact details -->

                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div style="background-color: #BFEFFF; margin-bottom:3px; min-height:450px;
                                    background-color:#BFEFFF; font-size:25px; font-family:pristina;">
                                    <br/>
                                    <marquee style="color:red;">The Company's Contact Details</marquee>
                                    
                                    <p>Our highly esteemed customers nationwide, you can do well to contact us through the followings:</p>
                                     <p><h3 style="color:red;">Phone number:</h3> 0814 037 4189, 0811 108 6922</p> 
                                     <p><h3 style="color:red;">Email:</h3> virtuosworld@gmail.com</p>
                                     <p style="color: red;">The company's address is shown below:</p>
                                     <p>Orisunmbare quarters Modakekeke, </br>
                                       Ile Ife, Osun State,</br> 
                                       Nigeria</p>                                   
                                    
                                </div>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
      </div>
    </div>

    <!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>



    </body>
</html>