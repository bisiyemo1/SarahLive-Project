<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VIRTUOSO OLA WORLD</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="customIfemi.css" rel="stylesheet" />

  </head>

  <body>

		

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">virtuosworld@gmail.com  <span class="glyphicon glyphicon-earphone">0814-037-4189, 0811-108-6922</span></span></h6>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/vowlogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>VIRTUOSO OLA WORLD</strong></h5></a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li class="active"><a href="about.php">About Us</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="formpage.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->

		
	<!--Code For jumbotron that contain vision, mission statement, and aim. -->
	
			<div class="container">
				<div class="jumbotron" style="background: #B0E2FF;">
					<p class="btn btn-lg btn-primary"><strong>Vission Statement</strong></p>			
					<p>Virtuoso World is a world of fashion designs with a vission to developing, producing and maintaining a unique and professional images in order to ensure that designs are produced at top quality thereby helping to seal the company’s popularity and professionalism.</p>

					<p class="btn btn-lg btn-primary"><strong>Mission Statement</strong></p>
					 <p>VIRTUOSO WORLD is a company who is dedicated to create unique design for our various clients in order to meet their taste and preference and also provide other fashion related services like training and sales of clothing accessories, a world-class event decorations and cake designs.</p>

					<p class="btn btn-lg btn-primary"><strong>Business Goal</strong></p>
					<p>Our goal is to make a unique ready-to-wear unisex dresses of various styles and native attires available to our customers and also to reduce unemployment and poverty by empowering young adult through professional trainings.  Our target group are business people, music and movie celebrities, models, male and female adult, movies producers, retail stores, boutiques, etc.</p>	
					<br/><br/><br/>	
				 </div>
			</div>

			<div class="container">
				<div class="jumbotron" style="background: #B0E2FF;">
					<!--Code For SECTION that contain FOUNDER'S PIX AND SPEECH -->

					<img src="images/founder9.jpg" class="pull-left img-thumbnail img-responsive" style="width:170px; height: 190px; margin-left: 0px;" /><!--center-block, pull-left, pull-right-->
						
					<h3 style="color: red;">Director's Speech</h3>
					<p>I welcome everyone to our official website for Virtuoso Ola World. Virtuoso World is a world of fashion designs, dedicated to create unique design for our various clients in order to meet their taste and preferences and also provide other fashion related services like training and sales of clothing accessories, event decorations and cake designs. We have a vision to facilitate our clients with our fashion piece while identify with the uniqueness in each of our clients. </br>

					We make a unique ready-to-wear unisex dresses of various styles and native attires available to our customers and also we reduce unemployment and poverty by empowering young adult.  Our target group are business people, music and movie celebrities, models, male and female adult, movies producers, retail stores and boutiques. </br>
						
					We have the goal of developing and maintaining a unique and professional images, to ensures that designs are produced at top quality and to help sealing the company’s popularity. Also we increase the scale of productions by employing more professionals.

					<p style="color: purple;">Our Services </p>
						•	Unisex Fashion Design Styles</br>
						•	Wedding Gan</br>
						•	Event Decorations</br>
						•	Wedding Cakes, Birthday Cakes, etc.
					</p>

					<p style="color: purple;">Our Strategies </p>
						•	We ensure that designs are produced at top quality in order to seal the company’s popularity and professionalism.</br>
						•	We maintain a strong relationship with our clients and keep clients update with the new styles</br>
						•	We develop a new perspective on fashion with each newline making ideas into reality without losing sight of concept in process.</br>
						•	We develop and maintain a unique fashion images.
					</p>
					<p>Finally, I am appealing to you to patronize us today and achieve the best. </p>

				</div>	
			</div>


	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>



			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>
		
    </body>
</html>
