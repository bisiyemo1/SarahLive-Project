<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VIRTUOSO OLA WORLD</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="customIfemi.css" rel="stylesheet" />

  </head>

  <body data-spy="scroll" data-target="#mainNavbar" data-offset="70">

		

			<!--CODES FOR HEADER AND NAVIGATION BAR -->
	
	<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">virtuosworld@gmail.com  <span class="glyphicon glyphicon-earphone">0814-037-4189, 0811-108-6922</span></span></h6>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="images/vowlogo.png" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>VIRTUOSO OLA WORLD</strong></h5></a>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="formpage.php">Contact Us</a></li>				
			</ul>

		</div>
	</div>
</div>

<p></p>br></p>
<p></p>br></p> 


<!--<div class="wrapper"> -->

		<!--Code for Column Picture slide show-->

<div class="container">
	<div class="row">
			
			<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
				<div class="panel-body">

					<div class="col-sm-4">
						<div style="margin-bottom:3px; min-height:350px; background-color:#BFEFFF; text-align:center;
								font-size:25px; font-family:pristina;">
							ELEGANT LADIES SUITE
							<div>
								<img src="images/gs21.jpg" class="img-responsive" style="height: 310px; width: 340px; margin-left: 0px;" />
							</div>
						</div>
					</div>


					<div class="col-sm-4"> <!--Iff the image is big use <div class="col-md-8 col-md-offset-2">-->
						
						<div id="imageCarousel" class="carousel slide" data-wrap="true" data-interval="4000"><!--Instead of javascript code for sliding you can use (data-ride="carousel")-->
							<ol class="carousel-indicators">
								<li data-target="#imageCarousel" data-slide-to="0" class="active"></li>
								<li data-target="#imageCarousel" data-slide-to="1"></li>
								<li data-target="#imageCarousel" data-slide-to="2"></li>
								<li data-target="#imageCarousel" data-slide-to="3"></li>
								<li data-target="#imageCarousel" data-slide-to="4"></li>
								<li data-target="#imageCarousel" data-slide-to="5"></li>
								<li data-target="#imageCarousel" data-slide-to="6"></li>
								<li data-target="#imageCarousel" data-slide-to="7"></li>
								<li data-target="#imageCarousel" data-slide-to="8"></li>
								<li data-target="#imageCarousel" data-slide-to="9"></li>
								<li data-target="#imageCarousel" data-slide-to="10"></li>
								<li data-target="#imageCarousel" data-slide-to="11"></li>
								<li data-target="#imageCarousel" data-slide-to="12"></li>
							</ol>
							<div class="carousel-inner img-responsive" style="height: 360px; width: 340px;">
								<div class="item active" style="height: 370px; width: 340px;">
									<img src="images/e6.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>AMAZING EVENT DECORATION 1</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/e7.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>UNBEATABLE EVENT DECORATION</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/gs14.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>ELEGANT FASHION STYLE</p>
									</div>
								</div>								

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/gs19.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>UNIQUE FASHION STYLE</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/img2.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>MEN SUITE 1</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/img13.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>MEN SUITE 2</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/gs3.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>LADIES STYLE 1</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/gs4.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>LADIES STYLE 2</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/ec16.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>CAKE DESIGN 1</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/ec18.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>CAKE DESIGN 2</p>
									</div>
								</div>
								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/w16.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>UNIQUE WEDDING GAN</U></p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/w21.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>FANTASTIC WEDDING GAN</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/n3.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>EXCELLENT ATTIRE 1</p>
									</div>
								</div>

								<div class="item" style="height: 370px; width: 340px;">
									<img src="images/n17.jpg" class="img-responsive" style="height: 350px; width: 350px;" />
									<div class="carousel-caption">
										<p>EXCELLENT ATTIRE 2</p>
									</div>
								</div>

							</div>
							<a href="#imageCarousel" class="carousel-control left" data-slide="prev">
								<span class="glyphicon glyphicon-chevron-left"></span>
							</a>

							<a href="#imageCarousel" class="carousel-control right" data-slide="next">
								<span class="glyphicon glyphicon-chevron-right"></span>
							</a>
						</div>

					</div>


					<div class="col-sm-4">
						<div style="margin-bottom:3px; min-height:350px; background-color:#BFEFFF; text-align:center;
								font-size:21px; font-family:pristina;">
							AMAZING EVENT DECORATION 
							<div>
								<img src="images/e12.jpg" class="img-responsive" style="height: 310px; width: 340px; margin-left: 0px;" />
							</div>
						</div>
					</div>

				</div>				
			</div>

			
	<!--Code for Column of about, gallery and contact links-->
		
			<div class="container">
				<br /><br />
				<div class="row">
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3><a style="color: white;">About</a></h3> "About page is specially design to know us better, what we stand for, vision, mission, our impact globally and..."<a href="about.php" style="color: blue;">more</a>"
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3><a style="color: white;">Gallery</a></h3>Gallery page is specially design to give you access to viewing our works on fashion design, event decorations, birthday cake designs and..."<a href="gallery.php" style="color: blue;">more</a>"
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3><a style="color: white;">Contact</a></h3> "Contact page is specially design to give you easy access to get in touch with us, for enquiry about anything and..."<a href="formpage.php" style="color: blue;">more</a>"
						</div>
					</div>
				</div>
			</div>			
	</div>				
</div>
		
<!--</div>-->


	<!--Code For footer is in "footer.php" using server-side include method-->

<?php include 'includes/footer.php'; ?>  



			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>
  		<script type="text/javascript">
  				/*Javascript for tutorial 51*/
  			$(document).ready(function () {
  				$('#imageCarousel').carousel();
  			});

  		</script> 
		
    </body>
</html>