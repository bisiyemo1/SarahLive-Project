-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2018 at 05:49 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adeola`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(200) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `total_amt` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amt`) VALUES
(117, 2, '0', 3, 'iPhone 5s', 'image2.jpg', 1, 25000, 25000),
(120, 9, '0', 3, 'iPhone New', 'image9.jpg', 1, 12000, 12000),
(127, 34, '0', 4, 'Hot Plate', 'image19.jpg', 1, 800, 800),
(134, 10, '0', 4, 'Yellow Ladies dress', 'image17.jpg', 1, 1000, 1000),
(135, 26, '0', 4, 'Brown Men Suite', 'image114.jpg', 1, 3000, 3000),
(136, 31, '0', 4, 'Black Kids Wear', 'image16.jpg', 1, 1000, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Ladies Suits'),
(2, 'Men''s Suits'),
(3, 'Event Decorations'),
(4, 'Cake Designs'),
(5, 'Wedding Gan'),
(6, 'Ladies General Wears'),
(7, 'Native Dresses');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_image`) VALUES
(1, 1, 'gs1.JPG'),
(2, 1, 'gs2.JPG'),
(3, 1, 'gs3.JPG'),
(4, 1, 'gs4.JPG'),
(5, 1, 'gs5.JPG'),
(6, 1, 'gs6.JPG'),
(7, 1, 'gs7.JPG'),
(8, 1, 'gs8.JPG'),
(9, 1, 'gs9.JPG'),
(10, 1, 'gs10.JPG'),
(11, 1, 'gs11.JPG'),
(12, 1, 'gs12.JPG'),
(13, 1, 'gs13.JPG'),
(14, 1, 'gs14.JPG'),
(15, 1, 'gs15.JPG'),
(16, 1, 'gs16.JPG'),
(17, 1, 'gs17.JPG'),
(18, 1, 'gs18.JPG'),
(19, 1, 'gs19.JPG'),
(20, 1, 'gs20.JPG'),
(21, 1, 'gs21.JPG'),
(22, 1, 'gs22.JPG'),
(23, 1, 'gs23.JPG'),
(24, 1, 'gs24.JPG'),
(25, 1, 'gs25.JPG'),
(26, 1, 'gs26.JPG'),
(27, 1, 'gs27.JPG'),
(28, 1, 'gs28.JPG'),
(29, 1, 'gs29.JPG'),
(30, 1, 'gs30.JPG'),
(31, 2, 'img1.JPG'),
(32, 2, 'img2.JPG'),
(33, 2, 'img3.JPG'),
(34, 2, 'img4.JPG'),
(35, 2, 'img5.JPG'),
(36, 2, 'img6.JPG'),
(37, 2, 'img7.JPG'),
(38, 2, 'img8.JPG'),
(39, 2, 'img9.JPG'),
(40, 2, 'img10.JPG'),
(41, 2, 'img11.JPG'),
(42, 2, 'img12.JPG'),
(43, 2, 'img13.JPG'),
(44, 2, 'img14.JPG'),
(45, 2, 'img15.JPG'),
(46, 3, 'e1.JPG'),
(47, 3, 'e2.JPG'),
(48, 3, 'e3.JPG'),
(49, 3, 'e4.JPG'),
(50, 3, 'e5.JPG'),
(51, 3, 'e6.JPG'),
(52, 3, 'e7.JPG'),
(53, 3, 'e8.JPG'),
(54, 3, 'e9.JPG'),
(55, 3, 'e10.JPG'),
(56, 3, 'e11.JPG'),
(57, 3, 'e12.JPG'),
(58, 3, 'e13.JPG'),
(59, 3, 'e14.JPG'),
(60, 3, 'e15.JPG'),
(61, 3, 'e16.JPG'),
(62, 3, 'e17.JPG'),
(63, 3, 'e18.JPG'),
(64, 3, 'e19.JPG'),
(65, 3, 'e20.JPG'),
(66, 3, 'e21.JPG'),
(67, 3, 'e22.JPG'),
(68, 3, 'e23.JPG'),
(69, 3, 'e24.JPG'),
(70, 3, 'e25.JPG'),
(71, 4, 'ec1.JPG'),
(72, 4, 'ec2.JPG'),
(73, 4, 'ec3.JPG'),
(74, 4, 'ec4.JPG'),
(75, 4, 'ec5.JPG'),
(76, 4, 'ec6.JPG'),
(77, 4, 'ec7.JPG'),
(78, 4, 'ec8.JPG'),
(79, 4, 'ec9.JPG'),
(80, 4, 'ec10.JPG'),
(81, 4, 'ec11.JPG'),
(82, 4, 'ec12.JPG'),
(83, 4, 'ec13.JPG'),
(84, 4, 'ec14.JPG'),
(85, 4, 'ec15.JPG'),
(86, 4, 'ec16.JPG'),
(87, 4, 'ec17.JPG'),
(88, 4, 'ec18.JPG'),
(89, 4, 'ec19.JPG'),
(90, 4, 'ec20.JPG'),
(91, 4, 'ec21.JPG'),
(92, 4, 'ec22.JPG'),
(93, 4, 'ec23.JPG'),
(94, 4, 'ec24.JPG'),
(95, 4, 'ec25.JPG'),
(96, 5, 'w1.JPG'),
(97, 5, 'w2.JPG'),
(98, 5, 'w3.JPG'),
(99, 5, 'w4.JPG'),
(100, 5, 'w5.JPG'),
(101, 5, 'w6.JPG'),
(102, 5, 'w7.JPG'),
(103, 5, 'w8.JPG'),
(104, 5, 'w9.JPG'),
(105, 5, 'w10.JPG'),
(106, 5, 'w11.JPG'),
(107, 5, 'w12.JPG'),
(108, 5, 'w13.JPG'),
(109, 5, 'w14.JPG'),
(110, 5, 'w15.JPG'),
(111, 5, 'w16.JPG'),
(112, 5, 'w17.JPG'),
(113, 5, 'w18.JPG'),
(114, 5, 'w19.JPG'),
(115, 5, 'w20.JPG'),
(116, 5, 'w21.JPG'),
(117, 5, 'w22.JPG'),
(118, 5, 'w23.JPG'),
(119, 5, 'w24.JPG'),
(120, 5, 'w25.JPG'),
(121, 6, 'g1.JPG'),
(122, 6, 'g2.JPG'),
(123, 6, 'g3.JPG'),
(124, 6, 'g4.JPG'),
(125, 6, 'g5.JPG'),
(126, 6, 'g6.JPG'),
(127, 6, 'g7.JPG'),
(128, 6, 'g8.JPG'),
(129, 6, 'g9.JPG'),
(130, 6, 'g10.JPG'),
(131, 6, 'g11.JPG'),
(132, 6, 'g12.JPG'),
(133, 6, 'g13.JPG'),
(134, 6, 'g14.JPG'),
(135, 6, 'g15.JPG'),
(136, 6, 'g16.JPG'),
(137, 6, 'g17.JPG'),
(138, 6, 'g18.JPG'),
(139, 6, 'g19.JPG'),
(140, 7, 'n1.JPG'),
(141, 7, 'n2.JPG'),
(142, 7, 'n3.JPG'),
(143, 7, 'n4.JPG'),
(144, 7, 'n5.JPG'),
(145, 7, 'n6.JPG'),
(146, 7, 'n7.JPG'),
(147, 7, 'n8.JPG'),
(148, 7, 'n9.JPG'),
(149, 7, 'n10.JPG'),
(150, 7, 'n11.JPG'),
(151, 7, 'n12.JPG'),
(152, 7, 'n13.JPG'),
(153, 7, 'n14.JPG'),
(154, 7, 'n15.JPG'),
(155, 7, 'n16.JPG'),
(156, 7, 'n17.JPG'),
(157, 7, 'n18.JPG'),
(158, 7, 'n19.JPG'),
(159, 7, 'n20.JPG'),
(160, 7, 'n21.JPG'),
(161, 7, 'n22.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `addres1` varchar(300) NOT NULL,
  `address2` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `addres1`, `address2`) VALUES
(1, 'demo', 'demo', 'demo@gmail.com', '12345', '123456789', 'kolkata', 'VIP ROAD'),
(4, 'Ade', 'Adeee', 'bisiyemo1@gmail.com', '3dbe00a167653a1aaee01d93e77e730e', '08032453815', 'Lagos street', 'Ikeja');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
