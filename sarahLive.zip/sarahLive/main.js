$(document).ready(function(){
	cat();
	product();
//JAVASCRIPT CODES TO FETCH OUT CATEGORY FROM THE DATABASE AND DISPLAY IT ORDERLY IN FRONT END. (Video Tutorial 6)
	function cat(){			
		$.ajax({
			url :  	"action.php",
			method: "POST",       //Using POST method to send data to server
			data	:  {category: 1},   //To specify Which data we are sending to server
			success	:  function(data) {
				$("#get_category") .html(data);
			}  //This function will be called if the request completed successfully
		})
	}
/* PHP CODES TO FETCH OUT PRODUCTS FROM THE DATABASE AND DISPLAY IT ORDERLY IN FRONT END. 
BY CLICKING "RELOAD" ICON IT WILL DISPLAY RANDOMLY. (Video Tutorial 8)*/
		function product(){
		$.ajax({
			url :  	"action.php",
			method: "POST",
			data	:  {getProduct:1},    //To specify Which data we are sending to server
			success	:  function(data) {
				$("#get_product") .html(data);
			}
		})
	}
/* PHP CODES TO SELECT A PARTICULAR CATEGORY(e.g ELECTRONICS, LADIES WEAR...) 
FROM THE DATABASE AND DISPLAY THE PRODUCT UNDER IT IN THE FRONT END. (Video Tutorial 9)*/
	$("body").delegate(".category","click",function(event){
		event.preventDefault();
		var cid = $(this).attr('cid');
		$.ajax({
			url 	:  "action.php",
			method	:  "POST",
			data	:  {get_selected_category:1,cat_id:cid},   //To specify Which data we are sending to server
			success	:  function(data) {
				$("#get_product") .html(data);
			}  //This function will be called if the request completed successfully
		})
	})


})