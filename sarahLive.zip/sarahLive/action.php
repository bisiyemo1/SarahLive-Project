<?php
include "db.php";
//PHP CODES TO FETCH OUT CATEGORY FROM THE DATABASE AND DISPLAY IT ORDERLY IN FRONT END. (Video Tutorial 6)
if(isset($_POST["category"])) {
	$category_query = "SELECT * FROM categories";
	$run_query = mysqli_query($con, $category_query);
	echo "
		<div class='nav nav-pills nav-stacked'>
			<li class='active'><a href='#'><h4>Categories<h4></a></li>
	";
	if(mysqli_num_rows($run_query) > 0) {
		while($row = mysqli_fetch_array($run_query)){
			$cid = $row["cat_id"];
			$cat_name = $row["cat_title"];
			echo "
					<li><a href='#' class='category' cid='$cid'>$cat_name</a></li>
			";
		}
		echo "</div>";
	}
}
//PHP CODES TO FETCH OUT PRODUCTS FROM THE DATABASE AND DISPLAY IT ORDERLY IN FRONT END. BY CLICKING "RELOAD" ICON IT WILL DISPLAY RANDOMLY. (Video Tutorial 8)
if(isset($_POST["getProduct"])) {
	$product_query = "SELECT * FROM products ORDER BY RAND() LIMIT 0,9";
	$run_query = mysqli_query($con, $product_query);
	if(mysqli_num_rows($run_query) > 0) {
		while($row = mysqli_fetch_array($run_query)){
			$pro_id    = $row['product_id'];
			$pro_cat   = $row['product_cat'];
			$pro_image = $row['product_image'];
			echo "
				<div class='col-md-4'>
						<div class='panel panel-info'>
							<div class='panel-heading'></div>
							<div class='panel-body'>
								<img class='img-responsive' style='width: 190px; height: 250px; margin-left: 2px;' src='images/$pro_image'/>
							</div>
							<div class='panel-heading'>
								<button pid='$pro_id' style='float: right;'</button>
							</div>
						</div>
				</div>
			";
		}
	}
}
//PHP CODES TO SELECT A PARTICULAR CATEGORY(e.g ELECTRONICS, LADIES WEAR) OR A PARTICULAR BRAND OR TO SEARCH FROM THE DATABASE AND DISPLAY THE PRODUCT UNDER IT IN THE FRONT END. (Video Tutorial 9 and 10)
if(isset($_POST["get_selected_category"]) || isset($_POST["selectBrand"]) || isset($_POST["search"])){
	if(isset($_POST["get_selected_category"])){
	$id = $_POST["cat_id"];
	$sql = "SELECT * FROM products WHERE product_cat = '$id'";	
	}
	
	$run_query = mysqli_query($con,$sql);
		while($row = mysqli_fetch_array($run_query)){
			$pro_id    = $row['product_id'];
			$pro_cat   = $row['product_cat'];
			$pro_image = $row['product_image'];
			echo "
				<div class='col-md-4'>
						<div class='panel panel-info'>
							<div class='panel-heading'></div>
							<div class='panel-body'>
								<img class='img-responsive' style='width: 190px; height: 250px; margin-left: 2px;' src='images/$pro_image'/>
							</div>
							<div class='panel-heading'>
								<button pid='$pro_id' style='float: right;'</button>
							</div>
						</div>
				</div>
			";
		}
}



?>